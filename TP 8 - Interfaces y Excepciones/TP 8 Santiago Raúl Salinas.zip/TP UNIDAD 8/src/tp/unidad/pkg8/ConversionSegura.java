/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
import java.util.InputMismatchException;
import java.util.Scanner;

public class ConversionSegura {
    public static void main(String[] args) {
        
        System.out.println("=== EJERCICIO 2: CONVERSIÓN DE CADENA A NÚMERO ===");
        
        // Usamos try-with-resources para asegurar que el Scanner se cierre automáticamente
        try (Scanner sc = new Scanner(System.in)) {
            
            System.out.print("Ingrese una linea de texto (ej. '123' o 'hola'): ");
            // Leemos la entrada como un String, ya que el usuario puede ingresar cualquier cosa
            String texto = sc.nextLine();
            
            // Operación de riesgo: convertir un String a int. Lanza NumberFormatException si el texto no es numérico.
            int numero = Integer.parseInt(texto.trim());
            
            System.out.println("Conversión exitosa. Número ingresado: " + numero);
            
        } catch (NumberFormatException e) {
            // Captura específica: Si el texto no puede convertirse a entero.
            System.out.println("ERROR: La cadena ingresada no tiene el formato numérico correcto.");
            System.out.println("Detalles del error: " + e.getMessage());
            
        } catch (Exception e) {
            // Captura cualquier otro error inesperado (ej. NullPointerException)
            System.out.println("ERROR INESPERADO: Ocurrió un problema durante la lectura.");
            
        }
        
        System.out.println("El programa finalizó de forma controlada.");
    }
}