/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
// Clase que define la excepción personalizada
public class EdadInvalidaException extends RuntimeException {
    
    // Solo necesitamos el constructor que recibe el mensaje
    public EdadInvalidaException(String message) {
        super(message);
    }
}