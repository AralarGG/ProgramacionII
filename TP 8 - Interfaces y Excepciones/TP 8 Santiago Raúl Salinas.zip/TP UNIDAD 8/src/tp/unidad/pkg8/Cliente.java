/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
// Archivo: Cliente.java
public class Cliente implements Notificable {
    private String nombre;
    private String email;
    
    public Cliente(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }
    
    // Implementación del contrato Notificable (Obligatorio)
    @Override
    public void notificarCambioEstado(String nuevoEstado) {
        System.out.printf("CLIENTE (%s): Notificación a %s. Su pedido ahora está en estado: %s.\n", 
            this.nombre, this.email, nuevoEstado);
    }
    
    public String getNombre() {
        return nombre;
    }
}