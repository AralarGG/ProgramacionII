/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LecturaArchivoSegura {
    public static void main(String[] args) {
        
        System.out.println("=== EJERCICIO 3: LECTURA DE ARCHIVO SEGURA ===");
        
        // La ruta 'inexistente.txt' forzará el error.
        String rutaArchivo = "ArchivoPrueba.txt"; 
        
        // El recurso debe declararse fuera del try para ser accesible en el finally
        BufferedReader br = null; 
        
        try {
            // Operación que lanza FileNotFoundException (Excepción Chequeada)
            System.out.println("Intentando abrir archivo: " + rutaArchivo);
            br = new BufferedReader(new FileReader(rutaArchivo)); 
            
            // Si el archivo se abre correctamente, leemos la primera línea
            String linea = br.readLine(); 
            System.out.println("Contenido leído: " + linea);
            
        } catch (FileNotFoundException e) {
            // Captura si el archivo no existe (FileNotFoundException)
            System.out.println("ERROR: El archivo no fue encontrado en la ruta especificada.");
            System.out.println("Detalles: " + e.getMessage());
            
        } catch (IOException e) {
            // Captura errores de lectura/escritura que no sean la inexistencia del archivo
            System.out.println("ERROR DE IO: Ocurrió un problema al leer el contenido.");

        } finally {
            // Bloque finally: Garantiza que el recurso se cierre siempre
            if (br != null) {
                try {
                    br.close();
                    System.out.println("Recurso cerrado en el bloque finally.");
                } catch (IOException ex) {
                    // Manejo del error si el cierre falla (se ignora o se registra)
                }
            }
        }
    }
}