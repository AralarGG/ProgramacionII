/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

import java.util.ArrayList; // Agrega esta línea
import java.util.List;      // Esta ya la tienes
/**
 *
 * @author San
 */
// Dentro de la clase Pedido.java

import java.util.ArrayList;
import java.util.List; // Necesario para la declaración List<Producto>

import java.util.ArrayList;
import java.util.List; // Necesario para la declaración List<Producto>

public class Pedido implements Pagable {
    
    // ATRIBUTOS
    private List<Producto> productos; // Colección dinámica 1:N
    private Cliente cliente; // Referencia al Cliente
    private String estado;
    
    // CONSTRUCTOR
    public Pedido(Cliente cliente) {
        // Inicialización obligatoria del ArrayList para la colección
        this.productos = new ArrayList<>(); 
        this.cliente = cliente;
        this.estado = "PENDIENTE";
    }
    
    public void agregarProducto(Producto p) {
        this.productos.add(p);
    }
    
    // Implementación del contrato Pagable
    @Override
    public double calcularTotal() {
        double total = 0;
        // Polimorfismo: Llama a calcularTotal() del Producto
        for (Producto p : productos) {
            total += p.calcularTotal(); 
        }
        return total;
    }
    
    // Método de Negocio: Cambia el estado y notifica (usa la interfaz Notificable)
    public void cambiarEstado(String nuevoEstado) {
        this.estado = nuevoEstado;
        
        if (cliente != null) {
            cliente.notificarCambioEstado(nuevoEstado);
        }
    }
    
}