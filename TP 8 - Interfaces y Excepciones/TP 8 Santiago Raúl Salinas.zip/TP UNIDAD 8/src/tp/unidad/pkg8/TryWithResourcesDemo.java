/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.io.BufferedReader;
import java.io.File; // Importación necesaria para usar la clase File
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class TryWithResourcesDemo {
    public static void main(String[] args) {
        
        System.out.println("=== EJERCICIO 5: TRY-WITH-RESOURCES ===");
        
        // Simplemente para dar un nombre al archivo, como en el ejemplo del profesor
        String nombreArchivo = "ArchivoPrueba.txt"; 
        
        // Se utiliza la clase File
        File archivo = new File(nombreArchivo); 
        
        // Implementación de la solución oficial: encadenando File e InputStream
        // Java se encarga de cerrar ambas instancias al salir del try.
        try (FileReader fr = new FileReader(archivo);
             BufferedReader reader = new BufferedReader(fr)) {
            
            System.out.println("Intentando leer archivo: " + nombreArchivo);
            
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("Contenido: " + line);
            }
            
        } catch (IOException e) {
            System.out.println("ERROR: Ocurrió un problema de I/O (Input/Output).");
            System.out.println("Detalles: " + e.getMessage());
        }
        
        System.out.println("\n Recurso cerrado automáticamente.");
    }
}