/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
// Archivo: Notificable.java
public interface Notificable {
    // Contrato: Obliga a cualquier clase que implemente esto a saber cómo enviar un mensaje.
    void notificarCambioEstado(String nuevoEstado);
}