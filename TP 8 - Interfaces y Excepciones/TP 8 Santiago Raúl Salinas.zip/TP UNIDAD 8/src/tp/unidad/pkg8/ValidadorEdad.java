/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
public class ValidadorEdad {
    
    // Este método lanza la excepción si la edad es inválida
    public static void validar(int edad) {
        if (edad <= 0 || edad >= 120) {
            // Se utiliza 'throw new' para lanzar nuestra excepción personalizada
            throw new EdadInvalidaException("Ingreso una edad invalida");
        }
    }
}