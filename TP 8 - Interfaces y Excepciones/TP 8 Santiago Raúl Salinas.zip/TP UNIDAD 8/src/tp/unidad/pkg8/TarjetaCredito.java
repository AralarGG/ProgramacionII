/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
public class TarjetaCredito implements PagoConDescuento {
    private String numero;
    
    public TarjetaCredito(String numero) {
        this.numero = numero;
    }
    
    @Override
    public boolean procesarPago(double monto) {
        System.out.printf("💲 Pago Tarjeta %s: Procesando $%.2f... \n", numero, monto);
        // Lógica real (validaciones, etc.) iría aquí
        return monto > 0; 
    }
    
    @Override
    public double aplicarDescuento(double monto) {
        // Descuento del 10%
        return monto * 0.90; 
    }
}