/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
public interface Pagable {
    
    // Este método es abstracto por defecto y obliga a las clases a implementarlo.
    double calcularTotal(); 
}