/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
// Implementa PagoConDescuento, por lo que debe implementar procesarPago() y aplicarDescuento()
public class PayPal implements PagoConDescuento {
    private String email;
    
    public PayPal(String email) {
        this.email = email;
    }
    
    @Override
    public boolean procesarPago(double monto) {
        System.out.printf("💲 Pago PayPal: Procesando $%.2f via %s... \n", monto, email);
        return monto > 0;
    }
    
    @Override
    public double aplicarDescuento(double monto) {
        // Ejemplo: Aplica un descuento fijo del 5%
        return monto * 0.95; 
    }
}