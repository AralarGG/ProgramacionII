/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
import java.util.InputMismatchException; // Necesario para manejar entradas no numéricas
import java.util.Scanner;

public class DivisionSegura {
    public static void main(String[] args) {
        
        System.out.println("=== EJERCICIO 1: DIVISIÓN SEGURA ===");
        
        // Usamos try-with-resources para asegurar que el Scanner se cierre automáticamente
        try (Scanner sc = new Scanner(System.in)) {
            
            System.out.print("Ingrese el numerador (entero): ");
            int numerador = sc.nextInt();
            
            System.out.print("Ingrese el divisor (entero): ");
            int divisor = sc.nextInt();
            
            // Código propenso a lanzar ArithmeticException (división por cero)
            int resultado = numerador / divisor; 
            
            System.out.println("Resultado de la división: " + resultado);
            
        } catch (ArithmeticException e) {
            // Captura específica de la división por cero
            System.out.println("ERROR ARITMÉTICO: No se puede dividir por cero. Ingrese un divisor diferente.");
            
        } catch (InputMismatchException e) {
            // Captura si el usuario introduce texto en lugar de un número
            System.out.println("ERROR DE ENTRADA: Tipo de dato inválido. Debe ingresar solo números enteros.");
            
        } 
        
        System.out.println("El programa finalizó de forma controlada.");
    }
}