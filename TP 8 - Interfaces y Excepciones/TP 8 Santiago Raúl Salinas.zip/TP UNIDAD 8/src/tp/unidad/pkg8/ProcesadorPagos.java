/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
public class ProcesadorPagos {
    
    // Método que utiliza el Polimorfismo por Interfaz
    public void realizarTransaccion(Pago medioDePago, double monto) {
        
        System.out.println("\n--- INICIANDO TRANSACCIÓN ---");
        
        // 1. Uso de instanceof para chequear si el medio es elegible para descuento (PagoConDescuento)
        if (medioDePago instanceof PagoConDescuento) {
            
            // 2. Downcasting (Seguro, porque ya lo verificamos)
            PagoConDescuento medioConDesc = (PagoConDescuento) medioDePago;
            
            // 3. Aplicar descuento (Lógica de negocio)
            double montoConDescuento = medioConDesc.aplicarDescuento(monto);
            
            System.out.printf("💸 Descuento Aplicado. Original: $%.2f | Final: $%.2f\n", monto, montoConDescuento);
            medioConDesc.procesarPago(montoConDescuento);
            
        } else {
            // 4. Procesar pago normal (Efectivo, Transferencia, etc.)
            System.out.println("No aplica descuento.");
            medioDePago.procesarPago(monto);
        }
    }
}