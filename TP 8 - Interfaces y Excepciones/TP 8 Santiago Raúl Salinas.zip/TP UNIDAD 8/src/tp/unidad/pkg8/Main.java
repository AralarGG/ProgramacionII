/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
import java.util.ArrayList;
import java.util.List;

public class Main {
    
    // Método Estático que utiliza el Polimorfismo por Interfaz
    // Acepta cualquier objeto que cumpla el contrato Pago
    public static void realizarTransaccion(Pago medioDePago, double monto) {
        
        System.out.println("\n--- INICIANDO TRANSACCIÓN ---");
        
        // 1. Uso de instanceof para chequear si el medio es elegible para descuento
        if (medioDePago instanceof PagoConDescuento) {
            
            // 2. Downcasting Seguro: Convertimos la referencia genérica a PagoConDescuento
            PagoConDescuento medioConDesc = (PagoConDescuento) medioDePago;
            
            // 3. Aplicar descuento (Lógica específica)
            double montoConDescuento = medioConDesc.aplicarDescuento(monto);
            
            System.out.printf("Descuento Aplicado. Original: $%.2f | Final: $%.2f\n", monto, montoConDescuento);
            // Llamada polimórfica a procesarPago (con el monto con descuento)
            medioConDesc.procesarPago(montoConDescuento);
            
        } else {
            // 4. Procesar pago normal (Efectivo, Transferencia, etc.)
            System.out.println("No aplica descuento.");
            medioDePago.procesarPago(monto); // Llamada polimórfica
        }
    }
    
    public static void main(String[] args) {
        
        // 1. Crear el Cliente y Medios de Pago
        Cliente clienteAna = new Cliente("Ana López", "ana@mail.com");
        
        // Crear las implementaciones concretas de la interfaz Pago
        TarjetaCredito tarjetaVisa = new TarjetaCredito("4111");
        PayPal cuentaPayPal = new PayPal("ana@mail.com");
        
        // Creamos una forma simple de pago sin descuento para el ejemplo
        class Transferencia implements Pago {
            @Override
            public boolean procesarPago(double monto) {
                System.out.printf("Pago Transferencia: Enviando $%.2f al banco.\n", monto);
                return true;
            }
        }
        Transferencia banco = new Transferencia();

        System.out.println("=== SISTEMA E-COMMERCE: INTERFACES Y NOTIFICACIONES ===");
        
        // 2. Crear un Pedido (Objeto Complejo)
        Pedido pedido1 = new Pedido(clienteAna); // Pedido asociado a Ana
        
        // Añadir productos
        pedido1.agregarProducto(new Producto("T101", "Laptop", 2500.00));
        pedido1.agregarProducto(new Producto("T102", "Mouse", 50.00));
        
        double totalPedido = pedido1.calcularTotal();
        
        System.out.printf("TOTAL DEL PEDIDO: $%.2f\n", totalPedido);
        
        // 3. Demostración de Notificación (Interfaz Notificable)
        System.out.println("\n--- 1. PRUEBA DE NOTIFICACIÓN ---");
        pedido1.cambiarEstado("ENVIADO"); // Llama a clienteAna.notificarCambioEstado()
        
        // 4. Demostración de Pago Polimórfico
        System.out.println("\n--- 2. PRUEBA DE PAGOS POLIMÓRFICOS ---");

        // Pago 1: Con Descuento (Tarjeta, implementa PagoConDescuento)
        realizarTransaccion(tarjetaVisa, totalPedido);
        
        // Pago 2: Sin Descuento (Transferencia, implementa solo Pago)
        realizarTransaccion(banco, 100.00); 
        
        // Pago 3: Con Descuento (PayPal, implementa PagoConDescuento)
        realizarTransaccion(cuentaPayPal, 500.00); 
    }
}