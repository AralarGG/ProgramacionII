/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
public class Producto implements Pagable {
    private String id; // Identificador único del producto.
    private String nombre; // Nombre del producto.
    private double precio; // Precio unitario.
    
    public Producto(String id, String nombre, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
    }
    
    // Implementación Obligatoria del Contrato Pagable
    @Override
    public double calcularTotal() {
        // Para un producto individual, el total es simplemente su precio.
        return this.precio;
    }
    
    // Getters necesarios
    public String getId() {
        return id;
    }

    public double getPrecio() {
        return precio;
    }

    public String getNombre() {
        return nombre;
    }
}