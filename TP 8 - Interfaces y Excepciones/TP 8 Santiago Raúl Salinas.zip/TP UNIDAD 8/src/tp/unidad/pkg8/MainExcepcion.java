/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg8;

/**
 *
 * @author San
 */
import java.util.Scanner;

public class MainExcepcion {
    public static void main(String[] args) {
        
        // Usamos un bloque try para intentar la operación que puede fallar
        try (Scanner scan = new Scanner(System.in)) {
            
            System.out.println("Ingrese una edad");
            
            // Leemos la entrada del usuario
            int edad = Integer.parseInt(scan.nextLine()); 
            
            // 1. Lógica para forzar la excepción si la edad es 124 (o cualquier valor fuera de 0-120)
            if (edad <= 0 || edad >= 120) {
                // Aquí llamamos directamente a la clase de excepción para obtener el formato deseado
                throw new EdadInvalidaException("Ingreso una edad invalida");
            }
            
        } catch (NumberFormatException e) {
            System.out.println("Error: El valor ingresado no es un número válido.");
            
        } catch (EdadInvalidaException e) {
            // 2. Bloque catch que captura nuestra excepción personalizada.
            // La salida debe ser exactamente como la pide el profesor: Nombre de la Excepción y el mensaje.
            System.out.println("Exception in thread \"main\" Excepciones.EdadInvalidaException: " + e.getMessage());
            
        } finally {
            System.out.println("\nCommand execution failed.");
        }
    }
}