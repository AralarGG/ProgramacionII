/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg6;

/**
 *
 * @author San
 */
public class Autor {
    // ATRIBUTOS (Estado) - Privados por Encapsulamiento
    private String id;
    private String nombre;
    private String nacionalidad;

    // CONSTRUCTOR (Inicializa el estado)
    public Autor(String id, String nombre, String nacionalidad) {
        this.id = id;
        this.nombre = nombre;
        this.nacionalidad = nacionalidad;
    }
    
    // MÉTODO: toString() (Para mostrar info legible)
    @Override
    public String toString() {
        // Formato para ser usado en el Libro: Nombre (Nacionalidad)
        return nombre + " (" + nacionalidad + ")";
    }
    
    // GETTERS (Permiten a otras clases leer los datos)
    public String getNombre() {
        return nombre;
    }
    // Agrega aquí los demás Getters si los necesitas (getId, getNacionalidad)
}