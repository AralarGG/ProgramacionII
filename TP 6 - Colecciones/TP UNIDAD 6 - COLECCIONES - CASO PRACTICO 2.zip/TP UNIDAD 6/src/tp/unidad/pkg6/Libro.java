/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg6;

/**
 *
 * @author San
 */
public class Libro {
    // ATRIBUTOS (Estado)
    private String isbn; 
    private String titulo; 
    private int anioPublicacion; 
    private Autor autor; // Atributo de tipo OBJETO (Asociación 1:1)

    // CONSTRUCTOR
    public Libro(String isbn, String titulo, int anioPublicacion, Autor autor) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
        this.autor = autor; // Asigna la referencia del Autor
    }

    // MÉTODO: mostrarInfo() (Para las listas en la Biblioteca)
    public void mostrarInfo() {
        System.out.printf("  ISBN: %s | Título: %s | Año: %d | Autor: %s\n", 
            isbn, titulo, anioPublicacion, autor.toString());
    }
    
    // GETTERS necesarios para las búsquedas y reportes de la Biblioteca
    public String getIsbn() {
        return isbn;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public Autor getAutor() {
        return autor;
    }
}