/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg6;

/**
 *
 * @author San
 */
import java.util.ArrayList;
import java.util.List; 

public class Biblioteca {
    // ATRIBUTOS (Composición 1:N)
    private String nombre;
    private List<Libro> libros; // Usamos List para mejor práctica, implementado con ArrayList

    // CONSTRUCTOR
    public Biblioteca(String nombre) {
        this.nombre = nombre;
        // Inicialización obligatoria del ArrayList
        this.libros = new ArrayList<>(); 
    }
    
    // MÉTODO: agregarLibro() (Implementación de la COMPOSICIÓN 1:N)
    public void agregarLibro(String isbn, String titulo, int anioPublicacion, Autor autor) {
        // La Biblioteca es responsable de crear la instancia del Libro (Composición)
        Libro nuevoLibro = new Libro(isbn, titulo, anioPublicacion, autor); 
        this.libros.add(nuevoLibro);
        System.out.printf("✅ Agregado: %s (%s)\n", titulo, isbn);
    }
    
    // MÉTODO: listarLibros()
    public void listarLibros() {
        System.out.println("\n--- LISTADO DE LIBROS EN: " + this.nombre + " ---");
        if (libros.isEmpty()) {
            System.out.println("La biblioteca no tiene libros.");
            return;
        }
        for (Libro libro : libros) { // Uso del ciclo for-each
            libro.mostrarInfo();
        }
    }
    
    // MÉTODO: buscarLibroPorlsbn(String isbn)
    public Libro buscarLibroPorIsbn(String isbn) {
        for (Libro libro : libros) {
            if (libro.getIsbn().equals(isbn)) {
                return libro;
            }
        }
        return null;
    }

    // MÉTODO: eliminarLibro(String isbn)
    public boolean eliminarLibro(String isbn) {
        // Se usa el ciclo for tradicional para poder obtener el índice
        for (int i = 0; i < libros.size(); i++) {
            Libro libroActual = libros.get(i);
            
            if (libroActual.getIsbn().equals(isbn)) {
                libros.remove(i); // Elimina el elemento por índice
                System.out.printf("✅ Eliminado: Libro con ISBN %s\n", isbn);
                return true;
            }
        }
        System.out.printf("❌ Error: Libro con ISBN %s no encontrado.\n", isbn);
        return false;
    }
    
    // MÉTODO: obtenerCantidadLibros()
    public int obtenerCantidadLibros() {
        return libros.size();
    }
    
    // MÉTODO: filtrarLibrosPorAnio(int anio)
    public void filtrarLibrosPorAnio(int anio) {
        System.out.printf("\n--- LIBROS PUBLICADOS EN %d ---\n", anio);
        boolean encontrado = false;
        for (Libro libro : libros) {
            if (libro.getAnioPublicacion() == anio) {
                libro.mostrarInfo();
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontraron libros publicados en ese año.");
        }
    }
    
    // MÉTODO: mostrarAutoresDisponibles()
    public void mostrarAutoresDisponibles() {
        System.out.println("\n--- AUTORES DISPONIBLES EN INVENTARIO ---");
        List<String> autoresYaListados = new ArrayList<>();
        for (Libro libro : libros) {
            String nombreAutor = libro.getAutor().getNombre();
            if (!autoresYaListados.contains(nombreAutor)) {
                System.out.println("• " + nombreAutor);
                autoresYaListados.add(nombreAutor);
            }
        }
    }
}