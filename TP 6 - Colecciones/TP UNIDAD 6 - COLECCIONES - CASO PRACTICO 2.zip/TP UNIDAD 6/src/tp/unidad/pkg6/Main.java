/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad.pkg6;

/**
 *
 * @author San
 */
public class Main {
    public static void main(String[] args) {
        
        // Tarea 1: Crear una biblioteca.
        Biblioteca bibliotecaCentral = new Biblioteca("Biblioteca Central UTN");
        
        // Tarea 2: Crear al menos tres autores
        Autor a1 = new Autor("A001", "Gabriel García Márquez", "Colombiana");
        Autor a2 = new Autor("A002", "Jorge Luis Borges", "Argentina");
        Autor a3 = new Autor("A003", "Isabel Allende", "Chilena");
        
        System.out.println("=== 1. AGREGANDO LIBROS (COMPOSICIÓN 1:N) ===");
        
        // Tarea 3: Agregar 5 libros asociados a alguno de los Autores a la biblioteca.
        // NOTA: La Biblioteca crea los objetos Libro internamente (Composición).
        bibliotecaCentral.agregarLibro("978-0307474728", "Cien Años de Soledad", 1967, a1);
        bibliotecaCentral.agregarLibro("978-0143105741", "El Amor en los Tiempos del Cólera", 1985, a1);
        bibliotecaCentral.agregarLibro("978-0141182745", "Ficciones", 1944, a2);
        bibliotecaCentral.agregarLibro("978-0141182738", "El Aleph", 1949, a2);
        bibliotecaCentral.agregarLibro("978-0345803276", "La Casa de los Espíritus", 1982, a3);
        
        // Tarea 4: Listar todos los libros mostrando su información y la del autor.
        bibliotecaCentral.listarLibros();

        System.out.println("\n=== 2. BÚSQUEDA Y FILTRADO ===");
        
        // Tarea 5: Buscar un libro por su ISBN y mostrar su información.
        String isbnBuscado = "978-0143105741";
        Libro libroBuscado = bibliotecaCentral.buscarLibroPorIsbn(isbnBuscado);
        if (libroBuscado != null) {
            System.out.println("✅ Libro encontrado por ISBN " + isbnBuscado + ":");
            libroBuscado.mostrarInfo();
        } else {
            System.out.println("❌ Libro con ISBN " + isbnBuscado + " no encontrado.");
        }

        // Tarea 6: Filtrar y mostrar los libros publicados en un año específico.
        bibliotecaCentral.filtrarLibrosPorAnio(1944);
        
        // Tarea 9: Listar todos los autores de los libros disponibles en la biblioteca.
        bibliotecaCentral.mostrarAutoresDisponibles();
        
        System.out.println("\n=== 3. OPERACIONES DE BAJA Y REPORTE ===");

        // Tarea 7: Eliminar un libro por su ISBN.
        String isbnEliminar = "978-0143105741"; // El Amor en los Tiempos del Cólera
        System.out.println(">>> Intentando eliminar ISBN: " + isbnEliminar + " <<<");
        bibliotecaCentral.eliminarLibro(isbnEliminar); 
        
        // Listamos para confirmar la eliminación
        bibliotecaCentral.listarLibros();
        
        // Tarea 8: Mostrar la cantidad total de libros en la biblioteca.
        System.out.println("\nCantidad total de libros restantes: " + bibliotecaCentral.obtenerCantidadLibros());
        
        System.out.println("\n=== FIN DE LAS TAREAS ===");
    }
}