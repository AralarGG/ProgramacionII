/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad7.Ejercicio1;

/**
 *
 * @author San
 */
public class Auto extends Vehiculo { 
    
    private int cantidadDePuertas;

    public Auto(String marca, String modelo, int cantidadDePuertas) {
        super(marca, modelo); 
        this.cantidadDePuertas = cantidadDePuertas;
    }

    @Override
    public void mostrarInfo() {
        // Finaliza la impresión con el dato específico y el SALTO DE LÍNEA FINAL
        System.out.println("Modelo: " + this.modelo + ", marca: " + this.marca + ", cantidad de puertas: " + cantidadDePuertas); 
    }
    
}