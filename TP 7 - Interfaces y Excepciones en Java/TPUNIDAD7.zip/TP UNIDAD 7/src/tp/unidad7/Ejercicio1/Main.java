/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package tp.unidad7.Ejercicio1;

public class Main {
    public static void main(String[] args) {

        // Instanciamos un auto (Tarea)
        Auto a = new Auto("Ford", "Focus", 5); 

        // Llamada al método sobrescrito
        a.mostrarInfo();
    }
}