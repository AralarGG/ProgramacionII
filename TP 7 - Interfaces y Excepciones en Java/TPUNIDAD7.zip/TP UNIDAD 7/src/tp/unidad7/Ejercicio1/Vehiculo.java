/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad7.Ejercicio1;

/**
 *
 * @author San
 */
public class Vehiculo {
    protected String marca;
    protected String modelo;

    public Vehiculo(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }

    // MÉTODO CORREGIDO: Usamos print (o printf sin \n) para dejar el cursor en la misma línea
    public void mostrarInfo() {
        System.out.println(" Modelo: " + modelo + " ,marca: " + marca);
    }
}