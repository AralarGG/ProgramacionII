/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad7.Ejercicio4;

import java.util.ArrayList;

/**
 *
 * @author San
 */

public class Main {
    public static void main(String[] args) {
        
        // 1. Inicializamos array vacío de animales (La declaración debe estar aquí, visible para todos)
        ArrayList<Animal> animales = new ArrayList<>();
        
        // 2. Creamos y agregamos animales al array
        Perro p1 = new Perro();
        Gato g1 = new Gato();
        Vaca v1 = new Vaca();
        
        animales.add(p1);
        animales.add(g1);
        animales.add(v1);
        
        // 3. Recorremos el array y llamamos al método hacerSonido()
        System.out.println("--- Los animales hacen sonido ---");
        for (Animal a : animales) {
            // Llamada polimórfica: cada uno ejecutará su versión sobrescrita
            a.hacerSonido();
        }
        
        // 4. Prueba del segundo método heredado (describirAnimal)
        System.out.println("\n--- Descripciones (Método Heredado) ---");
        v1.describirAnimal();
    }
}