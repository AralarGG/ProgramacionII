/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad7.Ejercicio2;

/**
 *
 * @author San
 */
import java.util.ArrayList;

// NOTA: Esta clase asume que las clases Figura, Circulo y Rectangulo 
// están en el mismo paquete.

public class Main {
    public static void main(String[] args) {
        // Creamos Array de figuras vacio
        ArrayList<Figura> figuras = new ArrayList<>();
        
        // Creamos y añadimos las figuras al Array
        Rectangulo r1 = new Rectangulo(4.0, 4.0, "Rectangulo 1");
        Rectangulo r2 = new Rectangulo(6.0, 4.0, "Rectangulo 2");
        Circulo c1 = new Circulo(10, "Circulo 1");
        Circulo c2 = new Circulo(15, "Circulo 2");
        
        figuras.add(r1);
        figuras.add(r2);
        figuras.add(c1);
        figuras.add(c2);
        
        //Recorremos y llamamos al metodo calcluar area
        for(Figura f : figuras) {
            f.calcularArea();
        }
    }
}