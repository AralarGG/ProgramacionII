/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad7.Ejercicio2;

/**
 *
 * @author San
 */
public abstract class Figura {
    
    // Atributo protegido para que las subclases lo usen directamente
    protected String nombre; 

    // Constructor: Necesario para inicializar el atributo heredado
    public Figura(String nombre) {
        this.nombre = nombre;
    }
    
    // MÉTODO ABSTRACTO: Obliga a las subclases a implementar esta lógica
    public void calcularArea() {
    }
}