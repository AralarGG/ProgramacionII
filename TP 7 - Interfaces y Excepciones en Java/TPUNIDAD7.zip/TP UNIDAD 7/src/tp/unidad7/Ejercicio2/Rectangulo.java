/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad7.Ejercicio2;

/**
 *
 * @author San
 */
public class Rectangulo extends Figura {
    
    private double base;
    private double altura;

    public Rectangulo(double base, double altura, String nombre) {
        super(nombre); // Llama al constructor de Figura
        this.base = base;
        this.altura = altura;
    }

    // Sobrescritura obligatoria del método abstracto
    @Override
    public void calcularArea() {
        // Fórmula del área del rectángulo: base * altura
        System.out.println("El area del Rectangulo: " + nombre + " es: " + (base * altura));
    }
}