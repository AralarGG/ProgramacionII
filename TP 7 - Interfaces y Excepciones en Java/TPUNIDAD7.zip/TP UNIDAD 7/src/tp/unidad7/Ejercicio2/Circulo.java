/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.unidad7.Ejercicio2;

/**
 *
 * @author San
 */
public class Circulo extends Figura {
    
    private double radio;

    public Circulo(double radio, String nombre) {
        super(nombre); // Llama al constructor de Figura
        this.radio = radio;
    }

    // Sobrescritura al metodo calcular area
    @Override
    public void calcularArea() {
        // Fórmula del área del círculo: Math.PI * radio * radio
        System.out.println("El area del circulo es: " + nombre + "es: " +  (Math.PI * radio * radio));
    }
}